package com.techwithsam.flutter_webview

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
