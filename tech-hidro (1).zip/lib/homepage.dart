import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:full_webview/check_internet.dart';
import 'webview/example2.dart';
import 'webview/example3.dart';
import 'webview/example4.dart';
import 'webview/example5.dart';

class HomePage extends StatefulWidget {
  HomePage({Key? key}) : super(key: key);

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  var _scaffoldKey = GlobalKey<ScaffoldState>();
  final WebExampleThree inAppBrowser = WebExampleThree();
  final WebExampleFour inAppChrome = WebExampleFour();
  String _url = "https://industrial.ubidots.com/accounts/signin/";
  int checkInt = 0;

  var options = InAppBrowserClassOptions(
    crossPlatform: InAppBrowserOptions(hideUrlBar: false, toolbarTopBackgroundColor: Colors.green),
    inAppWebViewGroupOptions: InAppWebViewGroupOptions(
      crossPlatform: InAppWebViewOptions(
        javaScriptEnabled: true,
        cacheEnabled: true,
        transparentBackground: true,
      ),
    ),
  );

  @override
  void initState() {
    super.initState();
    Future<int> a = CheckInternet().checkInternetConnection();
    a.then((value) {
      if (value == 0) {
        setState(() {
          checkInt = 0;
        });
        print('No internet connect');
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('No internet connection!'),
        ));
      } else {
        setState(() {
          checkInt = 1;
        });
        print('Internet connected');
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('Connected to the internet'),
        ));
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      appBar: AppBar(
        title: Text('TECH HIDRO'),
        centerTitle: true,
        elevation: 0,
      ),
      bottomNavigationBar: Padding(
        padding: EdgeInsets.fromLTRB(3, 6, 3, 6),
        child: RichText(
          text: TextSpan(
            text: 'SENAI AMERICANA - ',
            style: TextStyle(color: Colors.black),
            recognizer: TapGestureRecognizer()..onTap = () => _launchURL(),
            children: [
              TextSpan(
                text: 'https://americana.sp.senai.br/',
                style: TextStyle(color: Colors.green, fontWeight: FontWeight.w600),
                recognizer: TapGestureRecognizer()..onTap = () => _launchURL(),
              )
            ],
          ),
          textAlign: TextAlign.center,
        ),
      ),
      body: Center(
        child: SingleChildScrollView(
          child: Column(
            children: [
              SizedBox(height: 12),
              //
              Image.network(
                'https://raw.githubusercontent.com/lucascalu/foto/main/a.png',
              ),

              //
              Text('SEJA BEM VINDO!'),
              SizedBox(height: 12),
              MaterialButton(
                onPressed: () {
                  Navigator.of(context).push(MaterialPageRoute(builder: (context) => WebExampleFive(url: _url)));
                },
                child: Text(
                  'Entrar',
                  style: TextStyle(color: Colors.white),
                ),
                color: Colors.green[900],
                padding: EdgeInsets.symmetric(horizontal: 70, vertical: 12),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _launchURL() async => await canLaunch(_url) ? await launch(_url) : throw 'Could not launch $_url';
}
